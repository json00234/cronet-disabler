package com.example.cronetdisabler;
import android.content.Context;
import android.util.Log;
import java.util.concurrent.Executor;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class HookMain implements IXposedHookLoadPackage {
 private static final String TAG = "CronetDisabler";
 private static final String TARGET_PACKAGE = "com.ss.android.ugc.aweme";
 private static final String TARGET_CLASS = "org.chromium.CronetClient";
 private static final String TARGET_METHOD = "tryCreateCronetEngine";

 @Override
 public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
  if (!lpparam.packageName.equals(TARGET_PACKAGE)) return;

  Log.d(TAG, "Hooking target package");

  try {
   Class<?> cronetClass = XposedHelpers.findClass(TARGET_CLASS, lpparam.classLoader);
   XposedHelpers.findAndHookMethod(
    cronetClass, TARGET_METHOD,
    Context.class, boolean.class, boolean.class, boolean.class, boolean.class,
    String.class, Executor.class, boolean.class,
    new XC_MethodHook() {
     @Override protected void beforeHookedMethod(MethodHookParam param) {
      Log.d(TAG, "forcing null return");
      param.setResult(null);
     }
    }
   );
  } catch (Throwable t) { Log.e(TAG, "Hook failed: " + t.getMessage()); }
 }
}
